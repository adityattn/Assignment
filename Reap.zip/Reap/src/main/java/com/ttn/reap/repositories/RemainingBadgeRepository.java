package com.ttn.reap.repositories;

import com.ttn.reap.poJo.RemainingBadge;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RemainingBadgeRepository extends CrudRepository<RemainingBadge,Integer> {
}
