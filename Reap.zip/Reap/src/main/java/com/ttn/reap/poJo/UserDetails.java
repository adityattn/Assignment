package com.ttn.reap.poJo;

import javax.persistence.Id;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import java.io.Serializable;

@Entity
public class UserDetails implements Serializable {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Integer id;
    @Column(unique = true, nullable = false)
    private String email;
    @Column(nullable = false)
    private String name;
    private String user_name;
    private String password;
    private String role;
    private String activeStatus;
    private double total_point;

    public UserDetails(){}

    public UserDetails(Integer id,String email, String name, String user_name, String password, String role, String activeStatus, double total_point) {
        this.id=id;
        this.email = email;
        this.name = name;
        this.user_name = user_name;
        this.password = password;
        this.role = role;
        this.activeStatus = activeStatus;
        this.total_point = total_point;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(String activeStatus) {
        this.activeStatus = activeStatus;
    }

    public double getTotal_point() {
        return total_point;
    }

    public void setTotal_point(double total_point) {
        this.total_point = total_point;
    }

    @Override
    public String toString() {
        return "UserDetails{" +
                "id=" + id +
                ", email='" + email + '\'' +
                ", name='" + name + '\'' +
                ", user_name='" + user_name + '\'' +
                ", password='" + password + '\'' +
                ", role='" + role + '\'' +
                ", activeStatus='" + activeStatus + '\'' +
                ", total_point=" + total_point +
                '}';
    }
}
