package com.ttn.reap.enums;

public class Role {

}
