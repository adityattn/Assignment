package com.ttn.reap.repositories;

import com.ttn.reap.poJo.RecievedBadge;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RecievedBadgeRepository extends CrudRepository<RecievedBadge,Integer> {
}
