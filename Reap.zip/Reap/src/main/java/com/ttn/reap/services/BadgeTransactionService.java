package com.ttn.reap.services;

import com.ttn.reap.poJo.BadgeTransaction;
import com.ttn.reap.repositories.BadgeTransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BadgeTransactionService {

    @Autowired
   private BadgeTransactionRepository badgeTransactionRepository;
}
