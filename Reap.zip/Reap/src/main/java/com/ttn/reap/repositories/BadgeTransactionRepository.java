package com.ttn.reap.repositories;

import com.ttn.reap.poJo.BadgeTransaction;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BadgeTransactionRepository extends CrudRepository<BadgeTransaction,Integer> {
}
