package com.ttn.reap.services;

import com.ttn.reap.repositories.UserDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserDetailsService {
    @Autowired
   private UserDetailsRepository userDetailsRepository;
}
