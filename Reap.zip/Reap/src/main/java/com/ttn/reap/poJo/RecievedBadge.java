package com.ttn.reap.poJo;

import javax.persistence.Id;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class RecievedBadge implements Serializable {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Integer id;
    private int gold = 0, silver = 0, bronze = 0, points = 0;
    @OneToOne
    @JoinColumn(name = "UserId")
    private UserDetails userDetails;

    public RecievedBadge(){}

    public RecievedBadge(int gold, int silver, int bronze, int points, UserDetails userDetails) {
        this.gold = gold;
        this.silver = silver;
        this.bronze = bronze;
        this.points = points;
        this.userDetails = userDetails;
    }

    public RecievedBadge(UserDetails userDetails) {
        this.userDetails = userDetails;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getGold() {
        return gold;
    }

    public void setGold(int gold) {
        this.gold = gold;
    }

    public int getSilver() {
        return silver;
    }

    public void setSilver(int silver) {
        this.silver = silver;
    }

    public int getBronze() {
        return bronze;
    }

    public void setBronze(int bronze) {
        this.bronze = bronze;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public UserDetails getUserDetails() {
        return userDetails;
    }

    public void setUserDetails(UserDetails userDetails) {
        this.userDetails = userDetails;
    }
}
