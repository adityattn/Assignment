
package com.ttn.reap.poJo;

import javax.persistence.Id;
import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
public class BadgeTransaction implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    //    private int senderId, receiverId;
    @OneToOne
    private UserDetails sender;
    private UserDetails receiver;
    private Date date;
    private String badge;
    private String karma;
    private String reason;

    public BadgeTransaction(){}

    public BadgeTransaction(UserDetails sender, UserDetails receiver, Date date, String badge, String karma, String reason) {
        this.sender = sender;
        this.receiver = receiver;
        this.date = date;
        this.badge = badge;
        this.karma = karma;
        this.reason = reason;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public UserDetails getSender() {
        return sender;
    }

    public void setSender(UserDetails sender) {
        this.sender = sender;
    }

    public UserDetails getReceiver() {
        return receiver;
    }

    public void setReceiver(UserDetails receiver) {
        this.receiver = receiver;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getBadge() {
        return badge;
    }

    public void setBadge(String badge) {
        this.badge = badge;
    }

    public String getKarma() {
        return karma;
    }

    public void setKarma(String karma) {
        this.karma = karma;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}


