package com.ttn.reap.services;

import com.ttn.reap.repositories.RemainingBadgeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RecievedBadgeService {

    @Autowired
    private RemainingBadgeRepository remainingBadgeRepository;

}
