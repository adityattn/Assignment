package com.ttn.reap.controller;

import com.ttn.reap.poJo.BadgeTransaction;
import com.ttn.reap.poJo.RecievedBadge;
import com.ttn.reap.poJo.RemainingBadge;
import com.ttn.reap.poJo.UserDetails;
import com.ttn.reap.services.UserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {

    @Autowired
    UserDetailsService userDetailsService;

    @GetMapping("/user")
    public UserDetails user()
    { UserDetails details= new UserDetails(1,"aditya.com","adi","aditya","kumar","user","active",8000);

    System.out.println(details);
        return details;

    }

    @GetMapping("/")
    public ModelAndView dashboard(){
        ModelAndView  modelAndView=new ModelAndView("dashboard");
        return  modelAndView;
    }

    @GetMapping("userlogin")
    public ModelAndView loginuser(){
        ModelAndView  modelAndView=new ModelAndView("loginRegistration");
        return  modelAndView;
    }

    @GetMapping("badges")
    public ModelAndView badges(){
        ModelAndView  modelAndView=new ModelAndView("badges");
        return  modelAndView;
    }

    @GetMapping("adminadmin")
    public ModelAndView admin(){
        ModelAndView  modelAndView=new ModelAndView("adminpanel");
        return  modelAndView;
    }
}
